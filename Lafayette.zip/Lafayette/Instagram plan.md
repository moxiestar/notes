# Mosaic — Instagram Content Plan

A working playbook for marketing Mosaic on Instagram to parents of teens. Built around a founder-led, build-in-public approach rather than a polished brand account.

---

## Positioning

You are a UNC student building serious AI-literacy ed-tech for high schoolers. That intersection is the pitch — young enough to actually understand how teens use AI, serious enough to have built something for it. Parents on Instagram are anxious about AI and their kids; most of what they see is alarmist news or generic "10 ChatGPT tips." You can be the credible-but-relatable voice in between.

**Account choice:** Use your name (e.g., `@stellabella` or similar) with Mosaic as the thing you're building. Parents trust people, not logos. Spin off a Mosaic-branded account later if there's a reason.

**Visual aesthetic:** Scrappy and human. Your face, your camera roll, your dorm/coffee shop/desk. Do not over-design. Save the polished editorial look for the website.

---

## The three content pillars

Every piece of content should map to one of these. If it doesn't fit, don't post it.

**1. Founder story — "why I'm building this"**
Your motivation, observations from being a recent high schooler and current college student, what you see your peers doing wrong with AI, the moment you decided to build Mosaic. This is your differentiator — nobody else has it.

**2. Building in public**
Cowork prompts, design decisions, Supabase fights, late-night debugging, the rebrand from CodeMage to Mosaic, screenshots of the platform working (and breaking). This builds credibility with parents who want to know a real person is behind the product.

**3. AI literacy thought leadership**
The actual ideas behind Mosaic: why coding isn't the skill, what "the Art of Asking" means, what good vs bad AI use looks like for teens, why NC's CS requirement misses the point. This is the content most likely to get shared by parents to other parents.

---

## Format mix (weekly target)

| Format | Frequency | Why |
|---|---|---|
| Reels | 2–3 per week | Main reach driver; how new parents will find you |
| Carousels | 1 per week | Save and share content; best for thought leadership |
| Stories | Daily (1–4 per day) | Builds parasocial trust; low effort |
| Single-image feed posts | Skip | Barely move on the algorithm right now |

---

## Hook patterns that work for parents

Keep a running list. Add to it constantly. Every reel needs a hook in the first 1.5 seconds.

- "If your teen uses [X] for homework, you need to know this..."
- "I'm 20. I build AI tools. Here's what I'd tell my own parents..."
- "Schools are teaching AI wrong. Here's what they're missing."
- "Your kid's CS class won't teach them this — but they need it for college."
- "Stop telling your teen to learn to code." (contrarian — pivots to your thesis)
- "I built this because I watched my high school cousin do [X]..."
- "The difference between using AI and being used by AI..."
- "Three things every parent of a teen using ChatGPT should know."
- "A UNC student is building AI tools for high schoolers. Here's why that matters."

---

## First 30 days — ramp-up plan

The goal of the first month is not virality. It is to build a body of 12–16 posts so the account looks established when parents land on it, and to learn what your audience responds to.

### Week 0 — Setup (before you post anything)

- [ ] Decide on handle and bio. Bio formula: who you are + what you're building + who it's for + link to mosaiclearn.dev
- [ ] Update profile photo (a real photo of you, not a logo)
- [ ] Add Mosaic link to bio
- [ ] Pick 2–3 spots in your usual rotation with good natural light (one room at home, one coffee shop, one campus spot)
- [ ] Buy a phone tripod if you don't have one (~$15)
- [ ] Create a running notes file: `mosaic-content-ideas.md` — every hook, story, observation goes here
- [ ] Brain-dump 30 hook ideas from your own life and Mosaic experience (don't filter, just dump)
- [ ] Follow 30–50 accounts in adjacent spaces: parenting influencers, ed-tech founders, AI educators, teen-focused creators. Algorithm signal + reference material.

### Week 1 — Founder origin

- [ ] **Reel 1:** "I'm a UNC student building an AI literacy platform for high schoolers — here's why" (60 seconds, face to camera)
- [ ] **Reel 2:** "What I see my high school cousins doing with ChatGPT that scares me"
- [ ] **Carousel:** "Why I dropped everything to build Mosaic" (origin story, 8–10 slides)
- [ ] **Stories:** Behind-the-scenes of recording the reels, your workspace, what you're working on
- [ ] Reply to every comment within 24 hours

### Week 2 — Building in public

- [ ] **Reel 3:** Screen recording of you writing a Cowork prompt → result on the platform (sped up, with voiceover or captions)
- [ ] **Reel 4:** "Day in the life of a 20-year-old founder" (UNC + build sessions)
- [ ] **Carousel:** "What I shipped this week" — actual screenshots, real progress
- [ ] **Stories:** Real-time building. Show a bug, show the fix.

### Week 3 — AI literacy thought leadership

- [ ] **Reel 5:** "Coding isn't the skill anymore — here's what is" (contrarian hook → pivot to your thesis)
- [ ] **Reel 6:** Side-by-side: vague prompt vs precise prompt, same task, dramatically different output
- [ ] **Reel 7:** "5 prompts your teen should never copy from TikTok"
- [ ] **Carousel:** "What 'AI literacy' actually means — and what schools get wrong"

### Week 4 — Lean into what worked

- [ ] Look at analytics. Which reel got the most reach? Most saves? Most comments from parents (vs. peers)?
- [ ] Make 2–3 more reels in the highest-performing pillar
- [ ] **Carousel:** Recap or deeper dive on your best-performing topic
- [ ] Consider boosting your top organic post as a small ad ($20–50 test)

---

## Weekly cadence (post-month-1)

Once you're past the ramp, settle into a sustainable rhythm:

| Day | Posting |
|---|---|
| Monday | Reel (founder story or building in public) |
| Tuesday | Stories: what I'm working on |
| Wednesday | Carousel (thought leadership) |
| Thursday | Stories: behind-the-scenes |
| Friday | Reel ("What I shipped this week" or AI literacy take) |
| Weekend | Stories only — keep it light |

---

## Batch recording — your unfair advantage

The single biggest unlock for sustainable content is batching. Trying to record one reel a day will burn you out.

**Once a month, block one Sunday (3–4 hours):**

- Outfit changes (3–4 different looks)
- Different rooms / angles / lighting setups
- Record 6–10 reels in one session
- Edit during the week, post on schedule

**Sunday batch checklist:**
- [ ] Pick 6–10 hooks from your running ideas file
- [ ] Write a one-line beat sheet for each (hook → middle → CTA)
- [ ] Set up phone on tripod, check lighting
- [ ] Record each reel 2–3 times, pick the best take later
- [ ] Save raw clips to a "content" folder organized by date
- [ ] During the week: edit one per day, schedule via Meta Business Suite

---

## Carousel template (reusable)

Most of your carousels can follow this 8-slide structure:

1. **Hook slide:** Big claim or question (e.g., "Coding isn't the skill anymore.")
2. **The setup:** Why this matters / who this is for
3. **The problem:** What's broken or misunderstood
4. **The insight:** Your contrarian take
5. **Evidence / example:** Concrete proof
6. **Reframe:** What people should think instead
7. **What to do about it:** Practical takeaway
8. **CTA:** "Mosaic teaches this. Link in bio." (or similar)

Design: white background, large serif headline (Cormorant Garamond echoes the website), small monospace body text. Keep it editorial and uncluttered — this is where your design taste should show.

---

## Story strategy

Stories are where you build the parasocial layer. Lower stakes, higher frequency.

**What to post:**
- Coffee shop / desk setup / current view
- Cowork prompt you're writing (screenshot)
- Bug you're fixing (with a "watch me debug this" energy)
- Real student feedback (with permission, names redacted)
- A polled question to your audience ("Parents — what scares you most about AI and your teen?")
- Snippet of a parent meeting on Calendly (just the calendar, not the meeting)
- Late-night build sessions
- Wins and losses, in real time

**Story tactic:** every Friday, post a "what I shipped this week" story sequence — 4–6 frames, real screenshots. Save it as a Highlight called "BUILDING."

**Highlights to set up:**
- BUILDING — weekly progress
- MOSAIC — what is it, who's it for
- STUDENTS — testimonials and screenshots
- THE STORY — your founder origin

---

## Engagement system

For the first 90 days, treat engagement as a daily job, not an afterthought.

- [ ] Reply to every comment within 24 hours (yes, every one)
- [ ] DM every parent who messages you, personally
- [ ] Spend 15 minutes a day commenting on adjacent accounts (parenting, ed-tech, AI educators) — leave thoughtful replies, not just emoji
- [ ] When someone shares your post, DM them a thank-you
- [ ] Save every piece of feedback in a spreadsheet for testimonial use later

The algorithm rewards this. Your community grows through it. Both compound.

---

## Metrics to actually track

Don't get sucked into vanity metrics. The real signals:

- **Saves per reel** — best signal that content resonated with the audience that matters
- **Shares per reel** — best signal that parents are sending it to other parents
- **DMs from parents** — the highest-quality lead signal
- **Profile visits → link clicks** — your conversion funnel
- **Follower growth from non-followers reached** — quality of acquisition

Ignore: likes, comments from peers/friends, view count alone.

---

## What not to do

- Don't make a polished, branded "Mosaic" aesthetic that hides you. Parents trust people.
- Don't post "10 AI tools you must try" content. It's saturated and off-brand.
- Don't be doomy about AI. The ground truth is that parents are already anxious — your job is to be the calm, capable voice that says "here's what to actually do."
- Don't post inconsistently and then ghost. Better to post 2x a week reliably than 5x a week sporadically.
- Don't try to be funny if it doesn't come naturally. Your voice is thoughtful and serious-but-warm. Lean into that.
- Don't ignore comments. Especially the first 90 days.

---

## First action items (do this week)

1. Set up the account (handle, bio, photo, link)
2. Brain-dump 30 hook ideas to `mosaic-content-ideas.md`
3. Block a Sunday for your first batch recording session
4. Write the script for Reel 1 ("I'm a UNC student building...")
5. Follow 30–50 adjacent accounts
6. Pick a recurring posting day/time and add it to your calendar

The first reel doesn't need to be perfect. It needs to exist.
