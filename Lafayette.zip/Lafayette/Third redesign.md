## **Completed action items**
Signed up for [Calendly](https://calendly.com/app/scheduling/meeting_types/user/me) to book meetings with parents
Rebranded to Mosaic (mosaiclearn.dev)
UI redesign across all pages (landing, contact, login, error, game, etc)
**Huge game redesign** 
- Took inspiration from Gemini to add new features/levels
- Scrapped old curriculum completely
- Changed chat philosophy to push deeper conversations instead of copy/pasting
- Added specific objectives that automatically updates when students complete items
- Correctly implemented AI mentor to encourage & challenge students
- **Each level is a personalized challenge that results in a built-out project**
	- **Cool features:**
		- Desktop-style interface with different apps/files
		- Interactive dictionary
		- Built-in terminal with linux sandbox & Claude Code
		- Scratch-style block prompting exercise
		- “Under the hood” visualization
		- “Time machine” for prompt history
New codes created

-------------------------------------------------------------------
## **Current action items**
- **Fixes**
	- Create minimalistic intro/first level
	- Work on persistent memory (progress is not being saved)
	- Work on login mechanism - maybe that’s the main issue?
- **Follow up with parents again (send breakup emails)**
- **Prioritize content development**

-------------------------------------------------------------------
## **Upcoming action items**
**Find more Davidson Institute equivalent listservs**
- PTA leaders
- School counselors 
**Find more middle school & early high school teachers in NC** 
- Reach out with UNC email
**Post content on Instagram** 
- Find 50 best Instagram groups working with gifted parents
- Create reels and posts about me, my story, and Mosaic
- Look into affiliate program options (podcasts?)
